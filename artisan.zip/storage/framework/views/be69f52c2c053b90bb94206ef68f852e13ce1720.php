

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">Dashboard</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item active">Dashboards</li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-md-4">
                            <div class="d-flex flex-column h-100">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card card-animate">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div>
                                                        <p class="fw-medium text-muted mb-0">Pasien Hari Ini</p>
                                                        <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="<?php echo e($countPemeriksaan); ?>">0</span></h2>
                                                    </div>
                                                    <div>
                                                        <div class="avatar-sm flex-shrink-0">
                                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                                <i data-feather="users" class="text-info"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><!-- end card body -->
                                        </div> <!-- end card-->
                                    </div> <!-- end col-->

                                    <div class="col-12">
                                        <div class="card card-animate">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between">
                                                    <div>
                                                        <p class="fw-medium text-muted mb-0">Anak Stunting Hari Ini</p>
                                                        <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="<?php echo e($countPemeriksaanKurangSehat); ?>">0</span></h2>
                                                    </div>
                                                    <div>
                                                        <div class="avatar-sm flex-shrink-0">
                                                            <span class="avatar-title bg-soft-info rounded-circle fs-2">
                                                                <i data-feather="activity" class="text-info"></i>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><!-- end card body -->
                                        </div> <!-- end card-->
                                    </div> <!-- end col-->
                                </div> <!-- end row-->

                            </div>
                        </div> <!-- end col-->

                        <div class="col-md-8">
                            <div class="row h-100">
                                <div class="col-12">
                                    <div class="card card-height-100">
                                        <div class="card-header align-items-center d-flex">
                                            <h4 class="card-title mb-0 flex-grow-1">Laporan Pemeriksaan Perbulan</h4>
                                        </div><!-- end card header -->

                                        <!-- card body -->
                                        <div class="card-body">
                                            <div id="chart" data-colors='["--vz-primary", "--vz-success"]' class="apex-charts" dir="ltr"></div>
                                        </div><!-- end card-body -->
                                        <!-- end card body -->
                                    </div><!-- end card -->
                                </div><!-- end col -->
                            </div> <!-- end row-->
                        </div><!-- end col -->

                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">Data Anak</h5>
                                </div>
                                <div class="card-body">
                                    <table id="example" class="table dt-responsive nowrap table-striped align-middle" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th data-ordering="false">No.</th>
                                                <th>Nama</th>
                                                <th>Umur</th>
                                                <th>Alamat</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $birthDate = new DateTime($value->tglLahir);
                                                $today = new DateTime("today");   
                                            ?>
                                            <tr>
                                                <td><?php echo e($item+1); ?></td>
                                                <td><?php echo e($value->nama); ?>  </td>
                                                <td><?php echo e($today->diff($birthDate)->y); ?> Thn <?php echo e($today->diff($birthDate)->m); ?> Bulan</td>
                                                <td><?php echo e($value->alamat); ?>  </td>
                                                <td>
                                                    <div class="dropdown d-inline-block">
                                                        <button class="btn btn-soft-secondary btn-sm dropdown" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class="ri-more-fill align-middle"></i>
                                                        </button>
                                                        <ul class="dropdown-menu dropdown-menu-end">
                                                            <li><a href="<?php echo e(url('/')); ?>/admin/pasien/<?php echo e($value->id); ?>/show" class="dropdown-item"><i class="ri-eye-fill align-bottom me-2 text-muted"></i> View</a></li>
                                                            <li><a href="<?php echo e(url('/')); ?>/admin/pasien/<?php echo e($value->id); ?>/show" class="dropdown-item"><i class="ri-heart-2-line align-bottom me-2 text-muted"></i> Periksan</a></li>
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end row-->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

            <script>
                var data1 = [];
                var data2 = [];
                var tanggal = [];
            </script>
            <?php $__currentLoopData = $pemeriksaan_all_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script>
                    data1.push(<?php echo e($a); ?>);
                </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $pemeriksaan_kurang_gizi_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script>
                    data2.push(<?php echo e($b); ?>);
                </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $pemeriksaan_tanggal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script>
                    tanggal.push('<?php echo e($c); ?>');
                </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <script>
                var options = {
                    series: [
                        {
                            name: 'Anak Periksa',
                            type: 'column',
                            data: data1
                        }, {
                            name: 'Anak Stunting',
                            type: 'line',
                            data: data2
                        }
                    ],
                    chart: {
                        height: 350,
                        type: 'line',
                    },
                    stroke: {
                        width: [0, 4]
                    },
                    title: {
                        text: 'Pemeriksaan Hari Ini'
                    },
                    dataLabels: {
                        enabled: true,
                        enabledOnSeries: [1]
                    },
                        labels: tanggal,
                    xaxis: {
                        type: 'datetime'
                    },
                    yaxis: [
                        {
                            title: {
                                text: 'Pasien Periksa',
                            },
                            
                            }, {
                            opposite: true,
                            title: {
                                text: 'Pasien Kurang Gizi'
                            }
                        }
                    ]
                };

                var chart = new ApexCharts(document.querySelector("#chart"), options);
                chart.render();
            
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katc7678/public_html/stunting/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>