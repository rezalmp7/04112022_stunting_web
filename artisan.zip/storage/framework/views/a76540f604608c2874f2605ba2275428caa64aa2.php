

<?php $__env->startSection('content'); ?>
    <!-- start hero section -->
        <section class="section pb-0 hero-section py-5 my-5 bg-stunting-web" id="hero">
            <div class="container pb-5 mb-5">
                <div class="col-12 mt-5">
                    <form class="col-12 m-0 p-0" method="GET" action="<?php echo e(url('/')); ?>/pencarian">
                        <div class="input-group mb-3 position-relative">
                            <input type="text" class="form-control rounded-pill" name="search" placeholder="Search data Anda" aria-describedby="button">
                            <button class="submit-search top-50 position-absolute translate-middle" type="submit" id="button"><i class="ri-search-2-line"></i></button>
                        </div>
                    </form>
                    <div class="col-12 mb-5">
                        <div class="col-12 my-4 rounded shadow-lg table-responsive bg-light">
                            <table class="table">
                                <thead>
                                    <th class="text-center">Nama Balita</th>
                                    <th class="text-center">NIK</th>
                                    <th class="text-center">NO. KK</th>
                                    <th class="text-center">Tempat Tanggal Lahir</th>
                                    <th class="text-center">Jenis Kelamin</th>
                                    <th class="text-center">Umur (Tahun)</th>
                                    <th class="text-center">Nama Ibu Kandung</th>
                                    <th class="text-center">Alamat</th>
                                    <th class="text-center">Catatan Khusus</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pemeriksaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $birthDate = new DateTime($a->tglLahir);
                                        $today = new DateTime("today"); 
                                        $nikArray = str_split($a->nik);  
                                        $kkArray = str_split($a->kk);  
                                    ?>
                                    <tr class="fs-6">
                                        <th scope="row"><?php echo e($a->nama); ?></th>
                                        <td><?php echo e($nikArray[0].$nikArray[1].$nikArray[2]."xxxxxxxxxxxx"); ?></td>
                                        <td><?php echo e($kkArray[0].$kkArray[1].$kkArray[2]."xxxxxxxxxxxx"); ?></td>
                                        <td><?php echo e($a->tmpLahir); ?>, <?php echo e(date('d/m/Y', strtotime($a->tglLahir))); ?></td>
                                        <td><?php if($a->jenis_kelamin == "1"): ?>
                                            Laki - laki
                                        <?php else: ?>
                                            Perempuan
                                        <?php endif; ?></td>
                                        <td><?php echo e($today->diff($birthDate)->y); ?> Thn <?php echo e($today->diff($birthDate)->m); ?> Bulan</td>
                                        <td><?php echo e($a->orangTua); ?></td>
                                        <td><?php echo e($a->alamat); ?></td>
                                        <td><?php echo e($a->catatan); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end container -->
            <div class="position-absolute start-0 end-0 bottom-0 hero-shape-svg">
                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1440 120">
                    <g mask="url(&quot;#SvgjsMask1003&quot;)" fill="none">
                        <path d="M 0,118 C 288,98.6 1152,40.4 1440,21L1440 140L0 140z">
                        </path>
                    </g>
                </svg>
            </div>
            <!-- end shape -->
        </section>
        <!-- end hero section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katc7678/public_html/stunting/resources/views/dataStunting.blade.php ENDPATH**/ ?>