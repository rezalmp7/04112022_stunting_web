

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">Pemeriksaan</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item active">Pemeriksaan</li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0 d-inline">List Pemeriksaan</h5>
                                <a href="<?php echo e(url('/')); ?>/admin/pasien/create" class="btn btn-success btn-sm float-end"><i class=" ri-user-add-line"></i> Tambah Pasien</a>
                            </div>
                            <div class="card-body">
                                <table id="example" class="table dt-responsive nowrap table-striped align-middle" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th data-ordering="false">No.</th>
                                            <th>Nama</th>
                                            <th>Umur</th>
                                            <th>Alamat</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $birthDate = new DateTime($value->tglLahir);
	                                        $today = new DateTime("today");   
                                        ?>
                                        <tr>
                                            <td><?php echo e($item+1); ?></td>
                                            <td><?php echo e($value->nama); ?>  </td>
                                            <td><?php echo e($today->diff($birthDate)->y); ?> Thn <?php echo e($today->diff($birthDate)->m); ?> Bulan</td>
                                            <td><?php echo e($value->alamat); ?>  </td>
                                            <td>
                                                <div class="dropdown d-inline-block">
                                                    <button class="btn btn-soft-secondary btn-sm dropdown" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="ri-more-fill align-middle"></i>
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-menu-end">
                                                        <li><a href="<?php echo e(url('/')); ?>/admin/pasien/<?php echo e($value->id); ?>/show" class="dropdown-item"><i class="ri-eye-fill align-bottom me-2 text-muted"></i> View</a></li>
                                                        <li><a href="<?php echo e(url('/')); ?>/admin/pemeriksaan/<?php echo e($value->id); ?>/create" class="dropdown-item"><i class="ri-heart-add-fill align-bottom me-2 text-muted"></i> Tambah Periksan</a></li>
                                                        <li><a href="<?php echo e(url('/')); ?>/admin/pasien/<?php echo e($value->id); ?>/edit" class="dropdown-item edit-item-btn"><i class="ri-pencil-fill align-bottom me-2 text-muted"></i> Edit</a></li>
                                                        <li>
                                                            <a href="<?php echo e(url('/')); ?>/admin/pasien/<?php echo e($value->id); ?>/destroy" onclick="return confirm('Ingin menghapus <?php echo e($value->nama); ?> dari daftar pasien?');" class="dropdown-item remove-item-btn">
                                                                <i class="ri-delete-bin-fill align-bottom me-2 text-muted"></i> Delete
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katc7678/public_html/stunting/resources/views/admin/pemeriksaan/index.blade.php ENDPATH**/ ?>