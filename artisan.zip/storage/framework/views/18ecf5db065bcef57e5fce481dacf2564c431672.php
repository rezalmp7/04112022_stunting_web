

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">Artikel</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>/admin/dashboard">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>/admin/admin">Artikel</a></li>
                                        <li class="breadcrumb-item active">Edit</li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Edit Artikel</h5>
                            </div>
                            <div class="card-body p-4">
                                <form method="POST" action="<?php echo e(url('/')); ?>/admin/artikel/update/<?php echo e($artikel->id); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="my-3">
                                        <label for="basiInput" class="form-label">Judul</label>
                                        <input type="text" name="judul" class="form-control" value="<?php echo e($artikel->judul); ?>" required>
                                    </div>
                                    <div class="my-3">
                                        <label for="basiInput" class="form-label">Ganti Gambar</label><br>
                                        <img style="height: 100px" src="<?php echo e(url('/')); ?>/images/artikel/<?php echo e($artikel->gambar); ?>">
                                        <input type="file" name="gambar" class="form-control">
                                    </div>
                                    <div class="my-3">
                                        <label for="basiInput" class="form-label">Isi</label>
                                        <textarea name="isi" id="ckeditor" class="ckeditor form-control" cols="30" rows="10" required><?php echo e($artikel->description); ?></textarea>
                                    </div>
                                    <div class="my-3">
                                        <button class="btn btn-sm btn-warning float-end"><i class="ri-edit-2-line"></i> Edit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
            <script>
                ClassicEditor
				.create( document.querySelector( '.ckeditor' ), {
					
					licenseKey: '',
					
					
					
				} )
				.then( editor => {
					window.editor = editor;
			
					
					
					
				} )
				.catch( error => {
					console.error( 'Oops, something went wrong!' );
					console.error( 'Please, report the following error on https://github.com/ckeditor/ckeditor5/issues with the build id and the error stack trace:' );
					console.warn( 'Build id: dcxyp633umh-hv5gksn00e91' );
					console.error( error );
				} );
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/katc7678/public_html/stunting/resources/views/admin/artikel/edit.blade.php ENDPATH**/ ?>